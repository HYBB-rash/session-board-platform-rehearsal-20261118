import argparse
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile
from concurrent.futures import ThreadPoolExecutor

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from scripts.validate_candidate import ROOT, acceptance_outcome, commands_for, git, identity
from scripts.validation_report import verify_complete
from scripts.validate_context import require_remote_target, require_target

LINUX_JOBS = {"Candidate (linux-x86_64)", "Candidate gate", "Classify integration"}
JOBS = LINUX_JOBS | {"Candidate (macos-arm64)"}
PLATFORMS = {"linux-x86_64": ("linux", "x86_64"), "macos-arm64": ("darwin", "arm64")}
TARGETS = {"linux-x86_64": "x86_64-unknown-linux-gnu", "macos-arm64": "aarch64-apple-darwin"}


def github(*arguments, timeout=None):
    command = json.loads(os.environ.get("CODEX_GITHUB_COMMAND", '["gh"]'))
    if not isinstance(command, list) or not command or not all(isinstance(part, str) for part in command):
        raise ValueError("GitHub command must be a nonempty argument array")
    return subprocess.check_output([*command, *arguments], cwd=ROOT, text=True,
                                   stderr=subprocess.PIPE, timeout=timeout)


def validate_run(run, jobs, source, repository, required=JOBS):
    if (run["head_sha"] != source["commit"] or run["repository"]["full_name"] != repository
            or run["path"] != ".github/workflows/plugin-candidate.yml"
            or run["event"] not in ("push", "workflow_dispatch")
            or not run["head_branch"].startswith("codex/integration-")):
        raise ValueError("Actions run does not identify a successful integration candidate")
    records = {job["name"]: job for job in jobs["jobs"]}
    if not required.issubset(records) or any(
        records[name]["status"] != "completed" or records[name]["conclusion"] != "success"
        or records[name].get("head_sha", run["head_sha"]) != run["head_sha"]
        for name in required
    ):
        raise ValueError("Required candidate jobs must each finish successfully")
    return records


def artifact_name(name, job):
    attempt = job.get("run_attempt", 1)
    return f"{name}-{attempt}" if attempt > 1 else name


def validate_artifact(directory, source, label, base=None):
    record = json.loads((directory / "VALIDATION.json").read_text())
    verify_complete(directory, record)
    expected = {key: source[key] for key in ("commit", "tree", "fingerprint")}
    observed = record["source"]
    if (record["scope"] != "candidate" or record["passed"] is not True
            or any(observed[key] != value for key, value in expected.items())
            or (observed["platform"], observed["machine"]) != PLATFORMS[label]):
        raise ValueError("Validation artifact does not match the candidate and platform")
    scoped = "integration_sha256" in record
    report = directory / ("integration.json" if scoped else "automated.json")
    automatic = json.loads(report.read_text())
    report_key = "integration_sha256" if scoped else "automated_sha256"
    if (hashlib.sha256(report.read_bytes()).hexdigest() != record[report_key]
            or record["release_ready"] is not automatic["release_ready"]
            or record["acceptance_status"] != "not_performed"
            or (record["environment"]["platform"], record["environment"]["machine"]) != PLATFORMS[label]
            or [step["name"] for step in record["steps"]] != ["step-1", "step-2", "step-3"]
            or any(step["returncode"] != 0 for step in record["steps"])):
        raise ValueError("Candidate report is missing, unsuccessful or modified")
    strategy = None
    if scoped:
        from scripts.integration_plan import bound_inventory, plan, validate_report
        if base is None:
            raise ValueError("Scoped validation needs the fixed main baseline")
        strategy = plan(base)
        if strategy["profile"] == "full":
            raise ValueError("This candidate requires the complete automated report")
        bindings = json.loads((ROOT / "acceptance/bindings.json").read_text())
        expected_source = {**source, "platform": PLATFORMS[label][0],
                           "machine": PLATFORMS[label][1]}
        if record.get("plan") != strategy:
            raise ValueError("Validation plan differs from actual candidate changes")
        validate_report(automatic, strategy, expected_source,
                        bound_inventory(bindings, PLATFORMS[label][0]))
        if record.get("not_run") != automatic["not_run"]:
            raise ValueError("Scoped validation must preserve its omitted checks")
    elif (automatic["automated_passed"] is not True
          or automatic["build_sha256"] != source["fingerprint"]
          or not acceptance_outcome(automatic, record["steps"][2]["returncode"])):
        raise ValueError("Full automated acceptance did not pass")
    pending = (["完整自动验收", "目标环境验收"] if scoped else
               [item["id"] for item in automatic["requirements"] if item["status"] == "pending"])
    commands = [step["arguments"] for step in record["steps"]]
    expected_commands = commands_for(argparse.Namespace(scope="candidate"), Path("report"), strategy)
    if (record["pending"] != pending or len(commands) != 3
            or commands[:2] != expected_commands[:2]
            or commands[2][:-1] != expected_commands[2][:-1]
            or Path(commands[2][-1]).name != Path(expected_commands[2][-1]).name):
        raise ValueError("Candidate steps or pending evidence do not preserve the required checks")
    for step in record["steps"]:
        log = directory / f"{step['name']}.log"
        if hashlib.sha256(log.read_bytes()).hexdigest() != step["log_sha256"]:
            raise ValueError("Validation transcript does not match its recorded digest")
    return record


def collect_platform(repository, run, label, source, base, directory, job):
    validation = directory / "validation" / label
    github("run", "download", str(run), "--repo", repository,
           "--name", artifact_name(f"acceptance-{label}", job), "--dir", str(validation))
    record = validate_artifact(validation, source, label, base)
    return label, record, None


def advance(candidate, base, reference):
    subprocess.run(["git", "merge-base", "--is-ancestor", base, candidate], cwd=ROOT, check=True)
    subprocess.run(["git", "push", f"--force-with-lease={reference}:{base}",
                    "origin", f"{candidate}:{reference}"], cwd=ROOT, check=True)


def promote(candidate, base, run_id, repository, output, reference="refs/heads/main", *, pr_gates=None):
    output = output.resolve()
    if output.is_relative_to(ROOT) or output.exists():
        raise ValueError("Promotion receipt must use a new path outside the source")
    source = identity()
    if source["commit"] != candidate or git("status", "--porcelain", "--untracked-files=all"):
        raise ValueError("Promotion requires the exact clean committed candidate")
    subprocess.run(["git", "merge-base", "--is-ancestor", base, candidate],
                   cwd=ROOT, check=True)
    api = f"repos/{repository}/actions/runs/{run_id}"
    run = json.loads(github("api", api))
    jobs = json.loads(github("api", api + "/jobs?filter=latest&per_page=100"))
    labels = ("linux-x86_64",) if reference == "refs/heads/main" else tuple(PLATFORMS)
    records = validate_run(run, jobs, source, repository,
                           LINUX_JOBS if reference == "refs/heads/main" else JOBS)
    require_target(reference, base, run["head_branch"], candidate, git_command=git)
    if reference != "refs/heads/main":
        require_remote_target(reference, (base, candidate), git_command=git)
    output.parent.mkdir(parents=True, exist_ok=True)
    directory = Path(tempfile.mkdtemp(prefix="verified-candidate-", dir=output.parent))
    validations = {}
    with ThreadPoolExecutor(max_workers=2) as workers:
        futures = [workers.submit(collect_platform, repository, run_id, label, source,
                                  base, directory, records[f"Candidate ({label})"]) for label in labels]
        for future in futures:
            label, record, _package = future.result()
            validations[label] = record
    if identity() != source or git("status", "--porcelain", "--untracked-files=all"):
        raise ValueError("Candidate changed while checking remote validation")
    pr_checks = None
    if pr_gates:
        from scripts.pr_queue_gates import verify
        pr_checks = verify(pr_gates)
        if pr_checks is None:
            raise ValueError("Final PR checks are pending; refusing main promotion")
    remote = require_remote_target(reference, (base, candidate), git_command=git)
    if remote == base:
        if reference == "refs/heads/main":
            from scripts.main_release_feedback import require_recovery
            from scripts.main_release_evidence import require_version
            require_version(repository, base)
            require_recovery(repository, base)
        advance(candidate, base, reference)
    require_remote_target(reference, (candidate,), git_command=git)
    receipt = {
        "schema_version": 1, "source": source, "base": base, "reference": reference,
        "repository": repository, "run": run_id,
        "jobs": {name: {key: job.get(key) for key in ("id", "run_attempt", "html_url")}
                 for name, job in records.items() if name in LINUX_JOBS
                 or name in {f"Candidate ({label})" for label in labels}},
        "validated_platforms": validations,
        "merge_status": "merged", "release_status": "pending",
        "artifacts": str(directory),
        "pr_checks": pr_checks,
        "promoted_at": datetime.now(timezone.utc).isoformat(),
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_text(json.dumps(receipt, indent=2) + "\n")
    if reference == "refs/heads/main":
        from scripts.main_release import dispatch
        receipt["release"] = dispatch(repository, candidate)
        output.write_text(json.dumps(receipt, indent=2) + "\n")
    print(json.dumps({"promoted": candidate, "receipt": str(output)}))
    return receipt


def promote_context(candidate, base, run_id, repository, output):
    from scripts.validate_context import context_only
    output = output.resolve()
    source = identity()
    if (output.is_relative_to(ROOT) or output.exists() or source["commit"] != candidate
            or git("status", "--porcelain", "--untracked-files=all") or not context_only(base)):
        raise ValueError("Record promotion requires this exact clean context-only descendant")
    endpoint = f"repos/{repository}/actions/runs/{run_id}"
    run = json.loads(github("api", endpoint))
    jobs = json.loads(github("api", endpoint + "/jobs?filter=latest&per_page=100"))
    required = {"Classify integration", "Validate context records", "Candidate gate"}
    records = validate_run(run, jobs, source, repository, required)
    if any(job["name"] not in required and job["conclusion"] != "skipped"
           for job in jobs["jobs"]):
        raise ValueError("Record promotion requires the exclusive context validation path")
    output.parent.mkdir(parents=True, exist_ok=True)
    directory = Path(tempfile.mkdtemp(prefix="verified-context-", dir=output.parent))
    github("run", "download", str(run_id), "--repo", repository,
           "--name", artifact_name("context-validation", records["Validate context records"]),
           "--dir", str(directory))
    path = directory / "CONTEXT.json"
    report = json.loads(path.read_text())
    expected = {"scope": "context", "context_only": True, "base": base,
                "source_commit": candidate, "reference": "refs/heads/main",
                "implementation_unchanged": True}
    if report != expected or identity() != source or git("status", "--porcelain", "--untracked-files=all"):
        raise ValueError("Context evidence differs from the unchanged implementation and exact source")
    remote = require_remote_target("refs/heads/main", (base, candidate), git_command=git)
    if remote == base:
        advance(candidate, base, "refs/heads/main")
    require_remote_target("refs/heads/main", (candidate,), git_command=git)
    receipt = {"schema_version": 1, "scope": "context", "source": source, "base": base,
               "reference": "refs/heads/main", "repository": repository, "run": run_id,
               "context_report": str(path), "context_sha256": hashlib.sha256(path.read_bytes()).hexdigest(),
               "promoted_at": datetime.now(timezone.utc).isoformat()}
    output.write_text(json.dumps(receipt, indent=2) + "\n")
    return receipt


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--candidate", required=True)
    parser.add_argument("--base", required=True)
    parser.add_argument("--reference", default="refs/heads/main")
    parser.add_argument("--run", required=True, type=int)
    parser.add_argument("--repository", required=True)
    parser.add_argument("--output", required=True, type=Path)
    arguments = parser.parse_args()
    promote(arguments.candidate, arguments.base, arguments.run, arguments.repository,
            arguments.output, arguments.reference)


if __name__ == "__main__":
    main()

# PR 作者任务 CLI

项目内手动入口是 `.agents/skills/pr-task/SKILL.md`；确定性步骤由 `scripts/pr-task`
执行。它不替换 `validate`、合并队列、独立审阅或组合门禁。
GitHub PR 是反馈来源，合并方打回后继续看下一个。项目 skill 默认手动交接，
用户通知作者读取反馈；自动模式才由监控处理新反馈。

## 手动交接

仍使用同版本、同平台的冻结检查器和独立作者工作树；记录放在源码外。
项目 skill 负责准备这些路径和参数，用户只安排任务并转发 PR 链接。

```zsh
/absolute/frozen-checker/scripts/pr-task init --mode manual \
  --state /absolute/private/task-state --project /absolute/author-worktree \
  --repository OWNER/REPO --reviewer REVIEWER_LOGIN
/absolute/frozen-checker/scripts/pr-task submit --state /absolute/private/task-state \
  --title '本次改动' --body-file /absolute/pr-body.md
/absolute/frozen-checker/scripts/pr-task status --refresh --state /absolute/private/task-state
/absolute/frozen-checker/scripts/pr-task ready --state /absolute/private/task-state
```

`init --mode manual` 不连接客户端，不需要 socket，也不允许 `--archive`。
`--thread` 或 `CODEX_THREAD_ID` 仅用于作者身份；未提供时记录 `manual:分支名`，
不是客户端会话 ID。队列沿用该记录判断作者和独立审阅者，不向此身份发送消息。
手动 `submit` 不安装定时器，复用下文的准确头验证、普通推送和草稿 PR 创建。
同一任务的模式不可更改；旧记录没有 mode 字段时仍按 automatic 处理。
CLI 的 init 默认值仍为 automatic，以兼容既有调用；新 skill 显式选择 manual。

`status` 读取本地记录；`status --refresh` 额外读取 GitHub，并输出
`handoff`：链接、准确头、CI、反馈正文与来源链接、下一步。刷新不改 PR、任务记录、
标签或草稿状态，不连接客户端、不推进生命周期。`phase` 仍是上次本地操作的结果，
当前远端结果以带观察时间的 `handoff` 为准。请求失败直接报错，不当作无反馈或通过。
反馈沿用下文的受信审阅账号与结构化评论规则；普通讨论仍需作者阅读 PR。

`ready` 是显式写操作，要求本机已验证并提交当前 PR 头、工作树干净、CI 全部符合规则、
没有未解决反馈，然后复用已有入口移除草稿并公布 ready。重复执行仍复核证据，
复用原评论；重新转为草稿或修改标签后，不因旧 ready 标记跳过显式交付。
ready 只代表作者交付，可交给独立审阅者；不表示业务审阅或组合门禁通过。
CI 等待、失败或出现新反馈时刷新仍不执行修复。用户在原会话通知后，
作者修复并再次 submit，在 PR 回应处置及新头。仍有请求修改审阅时由审阅者复核，
不要为了 ready 擅自移除反馈，也不要求作者再修改已经修好的代码。

| 用户安排 | 会话停止位置 |
| --- | --- |
| 开发并提交 PR | 作者交付 ready 或明确阻塞，返回链接和当前头 |
| 独立审阅 PR | 将审阅结果写入 PR；阻塞项带源码与复现 |
| 处理 PR 反馈 | 修复、验证并回应，交回审阅者；不自我签收审阅 |
| 合并指定 PR | 复用队列核对证据、机械合并和组合门禁；合并或明确交接后返回，发布独立 |

确认 PR 已合并或关闭后执行 `finalize --state …`。只更新任务记录，
区分 merged 与 closed_without_merge，保留源码、会话及工作树，不调用客户端归档或调度器。
查询发现终态仍不自动 finalize。已关闭 PR 重新打开时需检查，不沿用完成任务重新开发。
手动模式拒绝 tick、schedule、probe、claim、complete、rebind、pause、resume，
防止误用自动运输入口；不存在需要后台续期的预算。网络或操作失败后可重试同一显式命令。
不要通过编辑 task.json 转换既有自动任务。
合并方的手动恢复及每轮报告见 [PR-QUEUE.md](PR-QUEUE.md)。
用户负责交接和再次调用；合并方不为自己或作者创建定时任务，也不等待作者领取反馈。

## 自动模式及共用交付规则

保留一个干净且版本固定的检查器工作树，队列和作者共用相同检查器版本及运行平台。
作者代码放在另一个独立工作树；所有运行记录放在源码外的私有目录：

```zsh
/absolute/frozen-checker/scripts/pr-task init --mode automatic --state /absolute/private/task-state \
  --project /absolute/author-worktree --repository OWNER/REPO --thread "$CODEX_THREAD_ID" \
  --socket /absolute/verified-client.sock --reviewer REVIEWER_LOGIN --archive
/absolute/frozen-checker/scripts/pr-task submit --state /absolute/private/task-state \
  --title '本次改动' --body-file /absolute/pr-body.md
/absolute/frozen-checker/scripts/pr-task status --state /absolute/private/task-state
```

`init` 固定分支、比较基线、原会话、端点对端 PID/启动身份、信任的审阅账号和预算。
同时固定检查器身份，拒绝把作者树本身当检查器。后续命令、定时器及作者唤起消息
均沿用这个入口；检查器变化会停下，不把过期报告交给队列。队列逐项 base 应沿用作者
报告的比较基线。后文相对命令均从冻结检查器目录执行；开发仍在作者树进行。
原会话可以从同一 Git 仓库的原目录进入任务；CLI 分别登记原目录和作者工作树，
拒绝跨仓库迁移。后续修复轮次的 cwd 指向作者树，不要求另造一个失去原上下文的会话。
一个仓库分支只允许一个未结束的作者任务；已有目录重复登记不会刷新预算。
默认必需检查名是本仓库的 `changes`，可重复 `--check` / `--reviewer` 显式设置。
不提供 reviewer 时使用当前 GitHub 登录账号；其他审阅账号必须显式登记。
仅支持 GitHub.com 同仓库 PR；不自动处理 fork、改目标分支或历史分支复用。

`submit` 要求干净的登记工作树，复用 `validate --scope pr --stage submit` 验证准确提交，
只作普通 push，不 force push。首次创建草稿 PR；已创建但丢失响应时按分支和持久
发布意图找回。相同源码且证据仍有效时复用报告，源码变化后重新验证。
本机报告通过且当前头的指定必需检查实际成功后，定时器才移除草稿并标记 ready。
其他检查仍须结束；按条件跳过或 neutral 的非必需作业不阻塞。必需检查缺失、
跳过或 neutral 继续等待，任何真实失败仍退回修复，不能用同名成功掩盖未完成或未通过项。
这只表示可以独立审阅，不代表已经合并、部署或完成客户端验收。
本机先执行受影响目标及全部 Python，推送后由 PR CI 执行完整 PR 范围，
候选继续执行双平台组合门禁。报告明确区分 submit 与 ci，不用本机轻量通过代替准确头 CI。

自动模式默认 macOS launchd 每 600 秒运行一次 `tick`，不启动模型等待。
机器关机、睡眠或当前轮仍在运行时可能延后，不承诺漏掉的每个 tick 都补跑。
安装前用定时器实际环境验证仓库读取、评论写入及标签权限。凭据适配器只接受单一
可执行入口 `CODEX_GITHUB_COMMAND='["/absolute/adapter"]'`，不把密钥写入 plist；
脚本需在后台独立取得现有授权。现有 `gh` 登录可直接复用。
Python 使用既有 3.11+ 环境及 `websocket-client`，不自动安装新运行时。
其他平台用 `submit --no-schedule` 和外部调度器执行 `tick`；未提供内置 Linux 调度器。

## 反馈与修复

```zsh
./scripts/pr-task feedback --repository OWNER/REPO --pr 123 --head FULL_SHA \
  --request-id STABLE_UUID --body-file /absolute/reproduction.md
./scripts/pr-task tick --state /absolute/private/task-state --force
./scripts/pr-task claim --state /absolute/private/task-state --event EVENT_UUID
./scripts/pr-task complete --state /absolute/private/task-state --event EVENT_UUID \
  --result fixed --message-file /absolute/disposition.md
```

`feedback` 使用稳定 UUID，发布绑定当前源码的可复现问题。同一 UUID 重试不会重复评论。
失败 CI、已发布的请求修改审阅、未解决的行内审阅及结构化队列反馈可触发修复。
不处理 PENDING 草稿审阅、已解决/过期行内讨论、普通聊天或自己的结果回执。
同账号作者和审阅者不会被一律过滤；每条事件保留原链接、源码、ID 和正文摘要。
读取全部分页后再次确认 PR 头和基线；失败、截断、漂移不等于空反馈或通过。

发现、投递、领取、完成分别持久记录。投递使用稳定 client ID；丢响应先查原轮次，
未能证明结果时不会换 ID 重发。原会话繁忙时等待，不中断；忙碌等待不消耗修复轮数。
只有登记的 `CODEX_THREAD_ID` 可以领取；领取时重新检查源码。领取后代码修复通过
`submit` 交付，并写 `complete` 回执。仍存在的同一次 CI 失败不能被签为修复完成。
未解决的问题用 `--result blocked`，停在 `needs-human`，不会自动反复消耗模型。

队列清单设置 `"feedback_mode": "github"`，即可复用 `pr-queue` 的冲突定位、PR 评论、
依赖跳过和组合验证；main 更新后另由自动发布产包，不再从合并方直接唤起作者或等待聊天 ACK。`requeue` 仍要求
准确源码的新审阅和验证。旧清单默认保留 native 模式，避免改变已运行队列。
同一 PR 不要同时启用 native 队列派单和作者监控。

## 恢复与结束

| 情况 | CLI 行为和恢复 |
| --- | --- |
| 网络、限流、临时失败 | 保留事件，退避重试；权限/归属错误暂停，先修正原因再 `resume` |
| 作者轮次失败或未调用 complete | 保留待办，进入 needs-human；确认原轮已结束后 `resume --retry-failed` |
| 修复有未提交代码 | 显式 retry 保留自己的改动；若已有未推送提交，先人工核对并 submit |
| 达到三轮或七十二小时 | 继续观察 PR 终态，但不发新修复；显式 `resume --additional-rounds N --extend-hours N` |
| 后台重启或换端点 | `rebind --socket …` 重新核验同一原会话；未知投递须能找到原 client ID |
| 会话出现别的用户输入 | 停止自动操作；人工核对后才能 `rebind --accept-input` |
| 终态清理中断 | `status` 显示恢复提示，执行 `finalize`；不创建第二个任务绕过旧记录 |
| 已关闭的 PR 重新打开 | 正在清理时停下等待检查；已结束的任务不能复活，另开登记记录 |

`pause` 阻止后续巡检，包括终态自动清理；修复原因后 `resume`。暂停不取消正在运行的
作者轮次，不删除已有定时器。写操作持有状态目录锁，重叠运行退出 75；
只读 status 读取原子保存的记录，不写锁文件。
队列收尾可调用 `tick --force --terminal-only`；它只处理合并/关闭，不为开放 PR 新建修复轮次。
`task.json` 是当前状态，`events.jsonl`、版本化投递回执、验证日志保留原始失败。

合并和未合并关闭分别记录。开启 `--archive` 时先核对原会话没有无关输入、
原会话与持久/临时子会话均空闲，再归档并读回确认。原生接口没有 CAS/if-idle 条件，
客户端两次检查仍不能完全消除外部同时输入的竞态，故只适用于独占的专用任务会话。
不加 `--archive` 仍自动停止监控，记录 `not_requested`，不冒称原生归档已完成。

定时器由独立 finalizer 移除；核对 plist 归属、删除本任务文件、卸载本任务服务、
读回确实不存在后才完成。不删除代码、分支、工作树或运行记录。
实现研究见 [PR-TASK-RESEARCH.md](PR-TASK-RESEARCH.md)。
